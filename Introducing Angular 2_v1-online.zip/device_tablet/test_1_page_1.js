TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3152":{"x":39,"y":601,"w":61.00,"h":40.00,"stylemods":[{"sel":"div.button3152Text","decl":" { position:fixed; left:2px; top:2px; width:56px; height:35px;}"},{"sel":"span.button3152Text","decl":" { display:table-cell; position:relative; width:56px; height:35px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_cancel_normal.png" ,"fdO": "images/std_qt_cancel_over.png" ,"fdD": "images/std_qt_cancel_clicked.png" ,"fdDi": "images/std_qt_cancel_normal.png" ,"p": "M 0.00 0.00 L 60.00 0.00 L 60.00 39.00 L 0.00 39.00 L 0.00 0.00 z"}
,
"button3170":{"x":909,"y":601,"w":61.00,"h":40.00,"stylemods":[{"sel":"div.button3170Text","decl":" { position:fixed; left:2px; top:2px; width:56px; height:35px;}"},{"sel":"span.button3170Text","decl":" { display:table-cell; position:relative; width:56px; height:35px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAoCAYAAABNefLBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAcqwEmSAAB8xoxpAAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_next_normal.png" ,"fdO": "images/std_qt_next_over.png" ,"fdD": "images/std_qt_next_clicked.png" ,"fdDi": "images/std_qt_next_normal.png" ,"p": "M 0.00 0.00 L 60.00 0.00 L 60.00 39.00 L 0.00 39.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":16,"w":589,"h":67,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":768,"y":309,"w":128,"h":128,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":963,"y":129,"w":47.00,"h":534.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:42px; height:529px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:42px; height:529px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAIWCAYAAADHzdTgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB5SURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBSA4pNAAHAGfa2AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 46.00 0.00 L 46.00 533.00 L 0.00 533.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":585,"w":1012.00,"h":78.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:1007px; height:73px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:1007px; height:73px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/QAAABOCAYAAACOnF3sAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFJSURBVHhe7cGBAAAAAMOg+VPf4ARVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARw3R6gABLWoZaAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 1011.00 0.00 L 1011.00 77.00 L 0.00 77.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":128,"w":47.00,"h":534.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:42px; height:529px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:42px; height:529px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAIWCAYAAADHzdTgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB5SURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBSA4pNAAHAGfa2AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 46.00 0.00 L 46.00 533.00 L 0.00 533.00 L 0.00 0.00 z"}
,
"text3225":{"x":84,"y":66,"w":453,"h":60,"txtscale":100,"bOffBottom":0}
,
"text3197":{"x":140,"y":200,"w":729,"h":37,"txtscale":100,"bOffBottom":0}
,
"text3198":{"x":185,"y":248,"w":702,"h":37,"txtscale":100,"bOffBottom":0}
,
"radio3199":{"x":137,"y":244,"fsize":16,"bOffBottom":0}
,
"text3200":{"x":183,"y":291,"w":702,"h":36,"txtscale":100,"bOffBottom":0}
,
"radio3201":{"x":137,"y":289,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/bkgnd.gif']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3152":{"x":30,"y":953,"w":48.00,"h":31.00,"stylemods":[{"sel":"div.button3152Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:26px;}"},{"sel":"span.button3152Text","decl":" { display:table-cell; position:relative; width:43px; height:26px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_cancel_normal.png" ,"fdO": "images/std_qt_cancel_over.png" ,"fdD": "images/std_qt_cancel_clicked.png" ,"fdDi": "images/std_qt_cancel_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 30.00 L 0.00 30.00 L 0.00 0.00 z"}
,
"button3170":{"x":707,"y":953,"w":48.00,"h":31.00,"stylemods":[{"sel":"div.button3170Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:26px;}"},{"sel":"span.button3170Text","decl":" { display:table-cell; position:relative; width:43px; height:26px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAfCAYAAACh+E5kAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAADgUwMXXwABlEb4PgAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_next_normal.png" ,"fdO": "images/std_qt_next_over.png" ,"fdD": "images/std_qt_next_clicked.png" ,"fdDi": "images/std_qt_next_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 30.00 L 0.00 30.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":16,"w":366,"h":67,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":598,"y":309,"w":100,"h":100,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":749,"y":129,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":585,"w":788.00,"h":61.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:783px; height:56px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:783px; height:56px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxQAAAA9CAYAAAA0yC/yAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADRSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXmrvawABFmxprgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 787.00 0.00 L 787.00 60.00 L 0.00 60.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":128,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"text3225":{"x":65,"y":66,"w":352,"h":76,"txtscale":100,"bOffBottom":0}
,
"text3197":{"x":109,"y":200,"w":567,"h":29,"txtscale":100,"bOffBottom":0}
,
"text3198":{"x":144,"y":248,"w":546,"h":29,"txtscale":100,"bOffBottom":0}
,
"radio3199":{"x":106,"y":244,"fsize":16,"bOffBottom":0}
,
"text3200":{"x":142,"y":291,"w":546,"h":28,"txtscale":100,"bOffBottom":0}
,
"radio3201":{"x":106,"y":289,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/bkgnd.gif']
}}
