TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3382":{"x":909,"y":602,"w":61.00,"h":41.00,"stylemods":[{"sel":"div.button3382Text","decl":" { position:fixed; left:2px; top:2px; width:56px; height:36px;}"},{"sel":"span.button3382Text","decl":" { display:table-cell; position:relative; width:56px; height:36px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_ok_normal.png" ,"fdO": "images/std_qt_ok_over.png" ,"fdD": "images/std_qt_ok_clicked.png" ,"fdDi": "images/std_qt_ok_normal.png" ,"p": "M 0.00 0.00 L 60.00 0.00 L 60.00 40.00 L 0.00 40.00 L 0.00 0.00 z"}
,
"button3387":{"x":40,"y":602,"w":61.00,"h":41.00,"stylemods":[{"sel":"div.button3387Text","decl":" { position:fixed; left:2px; top:2px; width:56px; height:36px;}"},{"sel":"span.button3387Text","decl":" { display:table-cell; position:relative; width:56px; height:36px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAApCAYAAACGJSFkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAADwpQYnPQABVbaNeQAAAABJRU5ErkJggg=="  ,"fd": "images/std_qt_print_normal.png" ,"fdO": "images/std_qt_print_over.png" ,"fdD": "images/std_qt_print_clicked.png" ,"fdDi": "images/std_qt_print_normal.png" ,"p": "M 0.00 0.00 L 60.00 0.00 L 60.00 40.00 L 0.00 40.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":16,"w":589,"h":67,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":768,"y":309,"w":128,"h":128,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":963,"y":129,"w":47.00,"h":534.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:42px; height:529px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:42px; height:529px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAIWCAYAAADHzdTgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB5SURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBSA4pNAAHAGfa2AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 46.00 0.00 L 46.00 533.00 L 0.00 533.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":585,"w":1012.00,"h":78.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:1007px; height:73px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:1007px; height:73px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/QAAABOCAYAAACOnF3sAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFJSURBVHhe7cGBAAAAAMOg+VPf4ARVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARw3R6gABLWoZaAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 1011.00 0.00 L 1011.00 77.00 L 0.00 77.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":128,"w":47.00,"h":534.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:42px; height:529px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:42px; height:529px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAIWCAYAAADHzdTgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB5SURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBSA4pNAAHAGfa2AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 46.00 0.00 L 46.00 533.00 L 0.00 533.00 L 0.00 0.00 z"}
,
"text9722":{"x":299,"y":234,"w":356,"h":34,"txtscale":100,"bOffBottom":0}
,
"text9681":{"x":119,"y":232,"w":176,"h":26,"txtscale":100,"bOffBottom":0}
,
"text9143":{"x":119,"y":323,"w":201,"h":49,"txtscale":100,"bOffBottom":0}
,
"text9107":{"x":118,"y":288,"w":166,"h":26,"txtscale":100,"bOffBottom":0}
,
"text9074":{"x":119,"y":188,"w":420,"h":50,"txtscale":100,"bOffBottom":0}
,
"text3617":{"x":85,"y":66,"w":453,"h":60,"txtscale":100,"bOffBottom":0}
,
"other3397":{"x":324,"y":287,"w":691,"h":218,"bOffBottom":0}
,
"shape9273":{"x":715,"y":272,"w":202.00,"h":209.00,"stylemods":[{"sel":"div.shape9273Text","decl":" { position:fixed; left:2px; top:2px; width:197px; height:204px;}"},{"sel":"span.shape9273Text","decl":" { display:table-cell; position:relative; width:197px; height:204px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMoAAADRCAYAAACNdC3wAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAC7SURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOClBpSXAAFGPfF/AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 201.00 0.00 L 201.00 208.00 L 0.00 208.00 L 0.00 0.00 z"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){other3397.growPage();}
,"preload":['images/bkgnd.gif']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3382":{"x":707,"y":953,"w":48.00,"h":32.00,"stylemods":[{"sel":"div.button3382Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button3382Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_ok_normal.png" ,"fdO": "images/std_qt_ok_over.png" ,"fdD": "images/std_qt_ok_clicked.png" ,"fdDi": "images/std_qt_ok_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 31.00 L 0.00 31.00 L 0.00 0.00 z"}
,
"button3387":{"x":31,"y":953,"w":48.00,"h":32.00,"stylemods":[{"sel":"div.button3387Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button3387Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_print_normal.png" ,"fdO": "images/std_qt_print_over.png" ,"fdD": "images/std_qt_print_clicked.png" ,"fdDi": "images/std_qt_print_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 31.00 L 0.00 31.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":16,"w":366,"h":67,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":598,"y":309,"w":100,"h":100,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":749,"y":129,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":585,"w":788.00,"h":61.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:783px; height:56px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:783px; height:56px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxQAAAA9CAYAAAA0yC/yAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADRSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXmrvawABFmxprgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 787.00 0.00 L 787.00 60.00 L 0.00 60.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":128,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"text9722":{"x":233,"y":234,"w":277,"h":26,"txtscale":100,"bOffBottom":0}
,
"text9681":{"x":93,"y":232,"w":137,"h":50,"txtscale":100,"bOffBottom":0}
,
"text9143":{"x":93,"y":323,"w":156,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9107":{"x":92,"y":288,"w":129,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9074":{"x":93,"y":188,"w":327,"h":75,"txtscale":100,"bOffBottom":0}
,
"text3617":{"x":66,"y":66,"w":352,"h":47,"txtscale":100,"bOffBottom":0}
,
"other3397":{"x":252,"y":287,"w":538,"h":170,"bOffBottom":0}
,
"shape9273":{"x":556,"y":272,"w":157.00,"h":163.00,"stylemods":[{"sel":"div.shape9273Text","decl":" { position:fixed; left:2px; top:2px; width:152px; height:158px;}"},{"sel":"span.shape9273Text","decl":" { display:table-cell; position:relative; width:152px; height:158px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAACjCAYAAACQVhwLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB6SURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/mqQjgABu2hggAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 156.00 0.00 L 156.00 162.00 L 0.00 162.00 L 0.00 0.00 z"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){other3397.growPage();}
,"preload":['images/bkgnd.gif']
}}
