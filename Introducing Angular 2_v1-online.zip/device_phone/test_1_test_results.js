PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":515,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3382":{"x":707,"y":468,"w":48.00,"h":32.00,"stylemods":[{"sel":"div.button3382Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button3382Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_ok_normal.png" ,"fdO": "images/std_qt_ok_over.png" ,"fdD": "images/std_qt_ok_clicked.png" ,"fdDi": "images/std_qt_ok_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 31.00 L 0.00 31.00 L 0.00 0.00 z"}
,
"button3387":{"x":31,"y":468,"w":48.00,"h":32.00,"stylemods":[{"sel":"div.button3387Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button3387Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_print_normal.png" ,"fdO": "images/std_qt_print_over.png" ,"fdD": "images/std_qt_print_clicked.png" ,"fdDi": "images/std_qt_print_normal.png" ,"p": "M 0.00 0.00 L 47.00 0.00 L 47.00 31.00 L 0.00 31.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":16,"w":366,"h":67,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":598,"y":240,"w":100,"h":100,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":749,"y":100,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":455,"w":788.00,"h":61.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:783px; height:56px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:783px; height:56px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxQAAAA9CAYAAAA0yC/yAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADRSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXmrvawABFmxprgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 787.00 0.00 L 787.00 60.00 L 0.00 60.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":100,"w":37.00,"h":416.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:411px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:32px; height:411px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAGgCAYAAAAtlK7cAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACASw3yIAABR5eQYgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 36.00 0.00 L 36.00 415.00 L 0.00 415.00 L 0.00 0.00 z"}
,
"text9722":{"x":233,"y":182,"w":277,"h":26,"txtscale":100,"bOffBottom":0}
,
"text9681":{"x":93,"y":180,"w":137,"h":50,"txtscale":100,"bOffBottom":0}
,
"text9143":{"x":93,"y":251,"w":156,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9107":{"x":92,"y":224,"w":129,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9074":{"x":93,"y":146,"w":327,"h":75,"txtscale":100,"bOffBottom":0}
,
"text3617":{"x":66,"y":51,"w":352,"h":47,"txtscale":100,"bOffBottom":0}
,
"other3397":{"x":252,"y":223,"w":538,"h":170,"bOffBottom":0}
,
"shape9273":{"x":556,"y":212,"w":157.00,"h":163.00,"stylemods":[{"sel":"div.shape9273Text","decl":" { position:fixed; left:2px; top:2px; width:152px; height:158px;}"},{"sel":"span.shape9273Text","decl":" { display:table-cell; position:relative; width:152px; height:158px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAACjCAYAAACQVhwLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB6SURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/mqQjgABu2hggAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.00 0.00 L 156.00 0.00 L 156.00 162.00 L 0.00 162.00 L 0.00 0.00 z"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){other3397.growPage();}
,"preload":['images/bkgnd.gif']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffe599","bgImage":"images/bkgnd.gif","bgSize":"12px 1540px","bgRepeat":"repeat-x"}
,
"button3382":{"x":432,"y":734,"w":30.00,"h":20.00,"stylemods":[{"sel":"div.button3382Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:15px;}"},{"sel":"span.button3382Text","decl":" { display:table-cell; position:relative; width:25px; height:15px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_ok_normal.png" ,"fdO": "images/std_qt_ok_over.png" ,"fdD": "images/std_qt_ok_clicked.png" ,"fdDi": "images/std_qt_ok_normal.png" ,"p": "M 0.00 0.00 L 29.00 0.00 L 29.00 19.00 L 0.00 19.00 L 0.00 0.00 z"}
,
"button3387":{"x":19,"y":734,"w":30.00,"h":20.00,"stylemods":[{"sel":"div.button3387Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:15px;}"},{"sel":"span.button3387Text","decl":" { display:table-cell; position:relative; width:25px; height:15px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_print_normal.png" ,"fdO": "images/std_qt_print_over.png" ,"fdD": "images/std_qt_print_clicked.png" ,"fdDi": "images/std_qt_print_normal.png" ,"p": "M 0.00 0.00 L 29.00 0.00 L 29.00 19.00 L 0.00 19.00 L 0.00 0.00 z"}
,
"text7598":{"x":23,"y":4,"w":251,"h":96,"txtscale":100,"bOffBottom":0}
,
"image7549":{"x":365,"y":309,"w":61,"h":61,"bOffBottom":0,"i":"images/if_question-y_86389.png"}
,
"shape7729":{"x":458,"y":129,"w":23.00,"h":255.00,"stylemods":[{"sel":"div.shape7729Text","decl":" { position:fixed; left:2px; top:2px; width:18px; height:250px;}"},{"sel":"span.shape7729Text","decl":" { display:table-cell; position:relative; width:18px; height:250px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAD/CAYAAAAaPU1PAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwI8aXKMAAb1vbTgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.00 0.00 L 22.00 0.00 L 22.00 254.00 L 0.00 254.00 L 0.00 0.00 z"}
,
"shape7809":{"x":0,"y":585,"w":482.00,"h":38.00,"stylemods":[{"sel":"div.shape7809Text","decl":" { position:fixed; left:2px; top:2px; width:477px; height:33px;}"},{"sel":"span.shape7809Text","decl":" { display:table-cell; position:relative; width:477px; height:33px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeIAAAAmCAYAAAAY55i1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABeSURBVHhe7cGBAAAAAMOg+VPf4ARVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHDR5lAAGEtBgdAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.00 0.00 L 481.00 0.00 L 481.00 37.00 L 0.00 37.00 L 0.00 0.00 z"}
,
"shape7686":{"x":0,"y":128,"w":23.00,"h":255.00,"stylemods":[{"sel":"div.shape7686Text","decl":" { position:fixed; left:2px; top:2px; width:18px; height:250px;}"},{"sel":"span.shape7686Text","decl":" { display:table-cell; position:relative; width:18px; height:250px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAD/CAYAAAAaPU1PAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwI8aXKMAAb1vbTgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.00 0.00 L 22.00 0.00 L 22.00 254.00 L 0.00 254.00 L 0.00 0.00 z"}
,
"text9722":{"x":142,"y":234,"w":169,"h":18,"txtscale":100,"bOffBottom":0}
,
"text9681":{"x":57,"y":232,"w":84,"h":50,"txtscale":100,"bOffBottom":0}
,
"text9143":{"x":57,"y":323,"w":96,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9107":{"x":56,"y":288,"w":79,"h":46,"txtscale":100,"bOffBottom":0}
,
"text9074":{"x":57,"y":188,"w":200,"h":100,"txtscale":100,"bOffBottom":0}
,
"text3617":{"x":40,"y":66,"w":216,"h":38,"txtscale":100,"bOffBottom":0}
,
"other3397":{"x":154,"y":287,"w":329,"h":104,"bOffBottom":0}
,
"shape9273":{"x":340,"y":272,"w":97.00,"h":100.00,"stylemods":[{"sel":"div.shape9273Text","decl":" { position:fixed; left:2px; top:2px; width:92px; height:95px;}"},{"sel":"span.shape9273Text","decl":" { display:table-cell; position:relative; width:92px; height:95px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGEAAABkCAYAAACWy14QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA8SURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABdql/QAAZRNxiQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.00 0.00 L 96.00 0.00 L 96.00 99.00 L 0.00 99.00 L 0.00 0.00 z"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){other3397.growPage();}
,"preload":['images/bkgnd.gif']
}}
